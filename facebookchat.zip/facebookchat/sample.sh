#!/bin/sh

#How to get Page id :
# * Go to https://findmyfbid.com/ and paste facebook page url'
# * Then it will show facebook page id

#How to get Access token:
# * Go to https://developers.facebook.com/tools/explorer and click 'Get User Access Token'
# * Then select 'manage_pages' and 'read_page_mailboxes'
# * Switch to a page that you want to scrape
# * Get the page_id and the token and pass as parameters to this script


FILE="facebook_chat.csv"
TOKEN="EAAEv3d5QgWgBAL2Vu71tt8BQrtq7Ix1eJY6OXdyizyVaunR7jqocfeaT7txvqcQnJLWISEKO1VZCc4ZCj1FlRBGdHrdWAlgpyUq80j9ptZCTl5BXnZBPcqF0FnhTT3gxpsEQf4P640i9OpSZBY9alzc1jWZB4ncqJSWZBt7o5sNdeur134KN2hdSdvxU0avLSNdxlDNgBaBdpZBtvxsaLQIk"
PAGE_ID="137710369601260"
python3 fb-page-chat-download/run.py $PAGE_ID $FILE $TOKEN
